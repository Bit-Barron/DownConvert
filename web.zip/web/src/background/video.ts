// chrome.webRequest.onBeforeRequest.addListener(
//   function (details) {
//     console.log(details);
//     chrome.storage.local.set({ [`${details.timeStamp}`]: details });
//   },
//   { urls: ["<all_urls>"] },
//   []
// );
