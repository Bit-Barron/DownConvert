interface Image {
  url: string;
  height: number;
}
